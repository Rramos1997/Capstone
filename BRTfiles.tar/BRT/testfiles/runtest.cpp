#include<iostream>
#include<string>

using namespace std;

int main(){
    int age;
    string name;

    cout<<"This is a test program. Please enter your name and age."<<endl;
    cin>>name>>age;
    cout<<endl<<"Your name is "<<name<<" and you are "<<age<<" years old."<<endl;
    return 0;
}
