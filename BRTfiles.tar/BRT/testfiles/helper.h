#ifndef HELPER_H
#define HELPER_H
#include<iostream>

class Helper{
    public:
        int age(std::string name);
};
#endif
